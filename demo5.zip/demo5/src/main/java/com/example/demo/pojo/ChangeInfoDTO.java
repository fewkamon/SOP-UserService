package com.example.demo.pojo;

public class ChangeInfoDTO {
    private UserInfo info;

    public ChangeInfoDTO(UserInfo info) {
        this.info = info;
    }

    public UserInfo getInfo() {
        return info;
    }
}
