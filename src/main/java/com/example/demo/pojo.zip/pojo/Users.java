package com.example.demo.pojo;

import java.util.ArrayList;
public class Users {
    public ArrayList<User> users;
}
