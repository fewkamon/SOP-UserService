package com.example.demo.pojo;

public class Address {
    private String province;
    private String tambon;
    private String amphur;
    private int postalcode;
    private String more;

    // Default Constructor
    public Address() {
    }

    // Parameterized Constructor
    public Address(String province, String tambon, String amphur, int postalcode, String more) {
        this.province = province;
        this.tambon = tambon;
        this.amphur = amphur;
        this.postalcode = postalcode;
        this.more = more;
    }

    // Getters and setters...
}